package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.Agent;

@Local
public interface AgentFacadeLocal {

    void create(Agent agent);
    void edit(Agent agent);
    void remove(Agent agent);
    Agent find(Object id);
    List<Agent> findAll();
    List<Agent> findRange(int[] range);
    int count();
    
    List<Agent> getAgentsByGender(Character gender);
    List<Agent> getMarriedAgentsByGender(Character gender);
    List<Agent> getAgentsByAgeRangeAndGender(Integer minAge, Integer maxAge, Character gender);
    Agent getOldestAgent();
    Long getNumAgentsPerGender(Character gender);
    Long getNumMarriedAgentsPerGender(Character gender);
    Long getNumAgentsPerAgeRangeAndGender(Integer minAge, Integer maxAge, Character gender);
}
