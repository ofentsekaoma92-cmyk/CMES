package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.entities.Agent;
import java.util.Date;

@Stateless
public class AgentFacade extends AbstractFacade<Agent> implements AgentFacadeLocal {

    @PersistenceContext(unitName = "TechnoByteSolutionsEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AgentFacade() {
        super(Agent.class);
    }

    @Override
    public List<Agent> getAgentsByGender(Character gender) {
       String queryStr = ("SELECT a FROM Agent a WHERE a.gender = ?1");
       Query query = em.createQuery(queryStr); 
       query.setParameter(1, gender);
       return (List<Agent>)query.getResultList();
    }

    @Override
    public List<Agent> getMarriedAgentsByGender(Character gender) {
       String queryStr = ("SELECT a FROM Agent a WHERE a.gender = ?1 AND a.maritalStatus = 'Married'");
       Query query = em.createQuery(queryStr); 
       query.setParameter(1, gender);
       return (List<Agent>)query.getResultList();
    }

    @Override
    public List<Agent> getAgentsByAgeRangeAndGender(Integer minAge, Integer maxAge, Character gender) {
       String queryStr = ("SELECT a FROM Agent a WHERE a.age >= ?1 AND a.age <= ?2 AND a.gender = ?3");
       Query query = em.createQuery(queryStr); 
       query.setParameter(1, minAge);
       query.setParameter(2, maxAge);
       query.setParameter(3, gender);
       return (List<Agent>)query.getResultList();
    }

    @Override
    public Agent getOldestAgent() {
        String queryStr = ("SELECT a FROM Agent a ORDER BY a.age DESC");
        Query query = em.createQuery(queryStr);
        query.setMaxResults(1);
        List<Agent> agents = (List<Agent>)query.getResultList();
        if (!agents.isEmpty()) {
            return agents.get(0);
        }
        return null;
    }

    @Override
    public Long getNumAgentsPerGender(Character gender) {
       String queryStr = ("SELECT count(a) FROM Agent a WHERE a.gender = ?1");
       Query query = em.createQuery(queryStr);
       query.setParameter(1, gender);
       return (Long)query.getSingleResult();
    }

    @Override
    public Long getNumMarriedAgentsPerGender(Character gender) {
       String queryStr = ("SELECT count(a) FROM Agent a WHERE a.gender = ?1 AND a.maritalStatus = 'Married'");
       Query query = em.createQuery(queryStr);
       query.setParameter(1, gender);
       return (Long)query.getSingleResult();
    }

    @Override
    public Long getNumAgentsPerAgeRangeAndGender(Integer minAge, Integer maxAge, Character gender) {
       String queryStr = ("SELECT count(a) FROM Agent a WHERE a.age >= ?1 AND a.age <= ?2 AND a.gender = ?3");
       Query query = em.createQuery(queryStr);
       query.setParameter(1, minAge);
       query.setParameter(2, maxAge);
       query.setParameter(3, gender);
       return (Long)query.getSingleResult();
    }
}
