/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.Student;

/**
 *
 * @author Student
 */
@Local
public interface StudentFacadeLocal {

    List<Student> findAll();
    List<Student> findRange(int[] range);
    void remove(Student student);
    void create(Student student);
    Long getNumStudentPerGender(Character gender);
    List<Student> getStudentPerGender(Character gender);
    Long getNumberOfStudentPerAgeRange(Integer minAge ,Integer maxAge);
    List<Student> getStudentPerAgeRange(Integer minAge ,Integer maxAge);
    Double getAvgAge();
    
    void edit(Student student);   
    Student find(Object id);
    int count();
    
}
