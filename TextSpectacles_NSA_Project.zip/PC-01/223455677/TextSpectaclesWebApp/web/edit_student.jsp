<%-- 
    Document   : edit_outcome
    Created on : 05 May 2026, 9:14:21 PM
    Author     : Student
--%>

<%@page import="za.ac.tut.entities.Student"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Edit Student Page</title>
    </head>
    <body>
        <h1>Edit Student</h1>
        <%
            Student stud = (Student) request.getAttribute("stud");
            String name = stud.getName();
            String surname = stud.getSurname();
            Long studno = stud.getId();
            Integer age = stud.getAge();
            Character gender = stud.getGender();

        %>
        <p>
            Below are the details of the student:
        </p>
        <table>
            <tr>
                <td>Name</td>
                <td><input type="text" name="<%=name%>" disabled=""></td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td>Surname</td>
                <td><input type="text" name="<%=surname%>" disabled=""></td>
                <td><input type="text" name="surname"></td>

            </tr>
            <tr>
                <td>Student Number</td>
                <td><input type="text" name="<%=studno%>" disabled=""></td>
                <td><input type="text" name="studno"></td>

            </tr>
            <tr>
                <td>Age</td>
                <td><input type="text" name="<%=age%>" disabled=""></td>
                <td><input type="text" name="age"></td>

            </tr>
            <tr>
                <td>Gender</td>
                <td><input type="text" name="<%=gender%>" disabled=""></td>
                <td><input type="text" name="gender"></td>

            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>

        </table>
        <ul>
            <li><a href="menu.html"> Menu Page</a></li>
            <li><a href="index.html"> Home Page</a></li>

        </ul>
    </body>
</html>
