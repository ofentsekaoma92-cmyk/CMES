<%-- 
    Document   : view_oldest_agent
    Created on : May 6, 2026, 10:00:00 AM
    Author     : Manus AI
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="za.ac.tut.entities.Agent"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Oldest Agent</title>
    </head>
    <body>
        <h1>Oldest Agent</h1>
        <% Agent oldestAgent = (Agent) request.getAttribute("oldestAgent"); %>
        
        <% if (oldestAgent != null) { %>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                    <th>Marital Status</th>
                    <th>Creation Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><%= oldestAgent.getId() %></td>
                    <td><%= oldestAgent.getName() %></td>
                    <td><%= oldestAgent.getSurname() %></td>
                    <td><%= oldestAgent.getAge() %></td>
                    <td><%= oldestAgent.getGender() %></td>
                    <td><%= oldestAgent.getDateOfBirth() %></td>
                    <td><%= oldestAgent.getMaritalStatus() %></td>
                    <td><%= oldestAgent.getCreationDate() %></td>
                </tr>
            </tbody>
        </table>
        <% } else { %>
        <p>No agents registered yet.</p>
        <% } %>
        <br>
        <a href="manager_menu.html">Back to Manager Menu</a>
    </body>
</html>
