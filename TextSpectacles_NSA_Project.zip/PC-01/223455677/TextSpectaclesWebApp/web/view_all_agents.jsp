<%-- 
    Document   : view_all_agents
    Created on : May 6, 2026, 10:00:00 AM
    Author     : Manus AI
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="za.ac.tut.entities.Agent"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>All Agents</title>
    </head>
    <body>
        <h1>All Registered Agents</h1>
        <% List<Agent> agents = (List<Agent>) request.getAttribute("agents"); %>
        <% if (agents != null && !agents.isEmpty()) { %>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                    <th>Marital Status</th>
                    <th>Creation Date</th>
                </tr>
            </thead>
            <tbody>
                <% for (Agent agent : agents) { %>
                <tr>
                    <td><%= agent.getId() %></td>
                    <td><%= agent.getName() %></td>
                    <td><%= agent.getSurname() %></td>
                    <td><%= agent.getAge() %></td>
                    <td><%= agent.getGender() %></td>
                    <td><%= agent.getDateOfBirth() %></td>
                    <td><%= agent.getMaritalStatus() %></td>
                    <td><%= agent.getCreationDate() %></td>
                </tr>
                <% } %>
            </tbody>
        </table>
        <% } else { %>
        <p>No agents registered yet.</p>
        <% } %>
        <br>
        <a href="manager_menu.html">Back to Manager Menu</a>
    </body>
</html>
