<%-- 
    Document   : add_outcome
    Created on : 05 May 2026, 8:34:14 PM
    Author     : Student
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Add Outcome Page</title>
    </head>
    <body>
        <h1>Add Outcome</h1>
        <p>
            The student has been successfully added.
        </p>
        <ul>
            <li><a href="menu.html"> Menu Page</a></li>
            <li><a href="index.html"> Home Page</a></li>
            
        </ul>

    </body>
</html>
