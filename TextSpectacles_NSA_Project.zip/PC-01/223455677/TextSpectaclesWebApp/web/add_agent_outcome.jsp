<%-- 
    Document   : add_agent_outcome
    Created on : May 6, 2026, 10:00:00 AM
    Author     : Manus AI
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Agent Added</title>
    </head>
    <body>
        <h1>Agent Added Successfully!</h1>
        <p>Agent ID: ${requestScope.agent.id}</p>
        <p>Name: ${requestScope.agent.name}</p>
        <p>Surname: ${requestScope.agent.surname}</p>
        <p>Age: ${requestScope.agent.age}</p>
        <p>Gender: ${requestScope.agent.gender}</p>
        <p>Date of Birth: ${requestScope.agent.dateOfBirth}</p>
        <p>Marital Status: ${requestScope.agent.maritalStatus}</p>
        <p>Creation Date: ${requestScope.agent.creationDate}</p>
        <br>
        <a href="add_agent.html">Add another agent</a><br>
        <a href="manager_menu.html">Back to Manager Menu</a>
    </body>
</html>
