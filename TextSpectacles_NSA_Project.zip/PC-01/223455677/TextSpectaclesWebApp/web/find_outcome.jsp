<%-- 
    Document   : find_outcome
    Created on : 05 May 2026, 8:58:50 PM
    Author     : Student
--%>

<%@page import="za.ac.tut.entities.Student"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Find Outcome Page</title>
    </head>
    <body>
        <h1>Find Outcome</h1>
        <%
            Student stud = (Student)request.getAttribute("stud");
            String name = stud.getName();
            String surname = stud.getSurname();
            Long studno = stud.getId();
            Integer age = stud.getAge();
            Character gender = stud.getGender();
            
            %>
            <p>
                Below are the details of the student:
            </p>
            <table>
                <tr>
                    <td>Name</td>
                    <th><%=name%></th>
                </tr>
                <tr>
                    <td>Surname</td>
                    <td><%=surname%></td>
                </tr>
                <tr>
                    <td>Student Number</td>
                    <td><%=studno%></td>
                </tr>
                 <tr>
                    <td>Age</td>
                    <td><%=age%></td>
                </tr>
                 <tr>
                    <td>Gender</td>
                    <td><%=gender%></td>
                </tr>
                
            </table>
                 <ul>
            <li><a href="menu.html"> Menu Page</a></li>
            <li><a href="index.html"> Home Page</a></li>
            
        </ul>
    </body>
</html>
