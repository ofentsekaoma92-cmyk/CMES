<%-- 
    Document   : remove_outcome
    Created on : 05 May 2026, 9:38:38 PM
    Author     : Student
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Remove Outcome Page</title>
    </head>
    <body>
        <h1>Remove Outcome </h1>
        <p>
            The student has been successfully removed.
        </p>
        <ul>
            <li><a href="menu.html"> Menu Page</a></li>
            <li><a href="index.html"> Home Page</a></li>
            
        </ul>
    </body>
</html>
