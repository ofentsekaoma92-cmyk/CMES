<!DOCTYPE html>
<html>
    <head>
        <title>Login Error</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <h1>Login Error</h1>
        <p>Invalid username or password. Please try again.</p>
        <a href="login.html">Back to Login</a>
    </body>
</html>
