<%-- 
    Document   : get_class_count_outcome_outcome
    Created on : 05 May 2026, 9:46:08 PM
    Author     : Student
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Get Count Class Page</title>
    </head>
    <body>
        <h1>Get Count Class </h1>
        <%
            Integer cnt = (Integer)request.getAttribute("cnt");
            
            %>
            <p>
                There are <b><%=cnt%></b> student in the class list.
                
            </p>
            <ul>
            <li><a href="menu.html"> Menu Page</a></li>
            <li><a href="index.html"> Home Page</a></li>
            
        </ul>
    </body>
</html>
