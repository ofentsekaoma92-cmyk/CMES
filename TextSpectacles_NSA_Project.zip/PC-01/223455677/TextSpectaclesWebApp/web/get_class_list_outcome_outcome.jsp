<%-- 
    Document   : get_class_list_outcome_outcome
    Created on : 05 May 2026, 9:54:28 PM
    Author     : Student
--%>

<%@page import="java.util.List"%>
<%@page import="za.ac.tut.entities.Student"%>
<%@page import="za.ac.tut.entities.Student"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>get_class_list_outcome_outcome</title>
    </head>
    <body>
        <h1>get_class_list_outcome_</h1>
        <%
             List<Student> stud = (List<Student>)request.getAttribute("stud");
             String name,surname;
             Long studno;
             Integer age;
             Character gender;
                     %>
                     <table>
                         <tr>
                             <th>Header</th>
                             <th>Header2</th>
                         </tr>
                         <tr>
                             <td>Cell1</td>
                             <td>Cell2</td>
                         </tr>
                         <tr>
                             <td>Cell3</td>
                             <td>Cell4</td>
                         </tr>
                     </table>
    </body>
</html>
