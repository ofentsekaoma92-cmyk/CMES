package za.ac.tut.web;

import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Agent;
import za.ac.tut.model.bl.AgentFacadeLocal;

public class GetAgentsByGenderServlet extends HttpServlet {

    @EJB
    private AgentFacadeLocal sfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Character gender = request.getParameter("gender").charAt(0);
        List<Agent> agents = sfl.getAgentsByGender(gender);
        Long count = sfl.getNumAgentsPerGender(gender);
        
        request.setAttribute("agents", agents);
        request.setAttribute("count", count);
        RequestDispatcher disp = request.getRequestDispatcher("view_agents_by_gender.jsp");
        disp.forward(request, response);
    }
}
