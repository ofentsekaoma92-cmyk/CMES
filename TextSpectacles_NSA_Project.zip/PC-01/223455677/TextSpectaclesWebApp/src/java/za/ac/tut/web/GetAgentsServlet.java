package za.ac.tut.web;

import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Agent;
import za.ac.tut.model.bl.AgentFacadeLocal;

public class GetAgentsServlet extends HttpServlet {

    @EJB
    private AgentFacadeLocal sfl;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Agent> agents = sfl.findAll();
        request.setAttribute("agents", agents);
        RequestDispatcher disp = request.getRequestDispatcher("view_all_agents.jsp");
        disp.forward(request, response);
    }
}
