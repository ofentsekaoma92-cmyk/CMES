package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Agent;
import za.ac.tut.model.bl.AgentFacadeLocal;

public class GetOldestAgentServlet extends HttpServlet {

    @EJB
    private AgentFacadeLocal sfl;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Agent oldestAgent = sfl.getOldestAgent();
        request.setAttribute("oldestAgent", oldestAgent);
        RequestDispatcher disp = request.getRequestDispatcher("view_oldest_agent.jsp");
        disp.forward(request, response);
    }
}
