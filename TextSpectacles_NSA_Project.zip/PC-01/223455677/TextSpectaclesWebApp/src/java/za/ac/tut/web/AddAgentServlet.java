package za.ac.tut.web;

import java.io.IOException;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Agent;
import za.ac.tut.model.bl.AgentFacadeLocal;

public class AddAgentServlet extends HttpServlet {

    @EJB
    private AgentFacadeLocal sfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        Integer age = Integer.parseInt(request.getParameter("age"));
        Character gender = request.getParameter("gender").charAt(0);
        String dobStr = request.getParameter("dateOfBirth");
        String maritalStatus = request.getParameter("maritalStatus");

        // Simple date parsing, consider using SimpleDateFormat for robust parsing
        Date dateOfBirth = null;
        try {
            dateOfBirth = java.sql.Date.valueOf(dobStr);
        } catch (IllegalArgumentException e) {
            // Handle parsing error, e.g., set to null or throw exception
            e.printStackTrace();
        }

        Date creationDate = new Date();

        Agent agent = new Agent();
        agent.setId(id);
        agent.setName(name);
        agent.setSurname(surname);
        agent.setAge(age);
        agent.setGender(gender);
        agent.setDateOfBirth(dateOfBirth);
        agent.setMaritalStatus(maritalStatus);
        agent.setCreationDate(creationDate);

        sfl.create(agent);

        request.setAttribute("agent", agent);
        RequestDispatcher disp = request.getRequestDispatcher("add_agent_outcome.jsp");
        disp.forward(request, response);
    }
}
