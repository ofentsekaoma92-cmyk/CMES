/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Student;
import za.ac.tut.model.bl.StudentFacadeLocal;

/**
 *
 * @author Student
 */
public class AddStudentServlet extends HttpServlet {

   @EJB StudentFacadeLocal sfl;
   
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Long studno = Long.parseLong(request.getParameter("studno"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        Integer age = Integer.parseInt(request.getParameter("age"));
        Character gender = request.getParameter("gender").charAt(0);
       
        Student stud = createStudent(name,surname,studno,age,gender);
        sfl.create(stud);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_outcome.jsp");
        disp.forward(request, response);
    }

    private Student createStudent(String name, String surname, Long studno, Integer age, Character gender) {
      
       Student stud = new Student();
       
       stud.setId(studno);
       stud.setName(name);
       stud.setName(surname);
       stud.setGender(gender);
       stud.setAge(age);
       stud.setCreationDate(new Date());
       return stud;
    }

}
